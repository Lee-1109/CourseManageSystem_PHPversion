create definer = root@localhost view view_base_insmajorclass as
select `i`.`instituteName` AS `学院`, `m`.`majorName` AS `专业`, `c`.`classID` AS `班级`
from `php_liyang`.`institutes` `i`
         join `php_liyang`.`majors` `m`
         join `php_liyang`.`classes` `c`
where ((`i`.`instituteID` = `m`.`instituteID`) and (`c`.`majorID` = `m`.`majorID`));


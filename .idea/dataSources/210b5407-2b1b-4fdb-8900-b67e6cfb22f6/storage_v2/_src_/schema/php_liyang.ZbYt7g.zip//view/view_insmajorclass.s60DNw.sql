create definer = root@localhost view view_insmajorclass as
select `i`.`instituteID`   AS `insID`,
       `i`.`instituteName` AS `insName`,
       `m`.`majorID`       AS `majorID`,
       `m`.`majorName`     AS `majorName`,
       `c`.`classID`       AS `classID`
from ((`php_liyang`.`institutes` `i` join `php_liyang`.`majors` `m`)
         join `php_liyang`.`classes` `c`)
where ((`i`.`instituteID` = `m`.`instituteID`) and (`c`.`majorID` = `m`.`majorID`));


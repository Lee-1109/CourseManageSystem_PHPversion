create definer = root@localhost view view_teacherdetail as
select `i`.`instituteID`   AS `insID`,
       `i`.`instituteName` AS `insName`,
       `m`.`majorName`     AS `majorName`,
       `t`.`teacherID`     AS `teacherID`,
       `t`.`teacherName`   AS `teacherName`,
       `t`.`Salary`        AS `Salary`
from `php_liyang`.`teachers` `t`
         join `php_liyang`.`majors` `m`
         join `php_liyang`.`institutes` `i`
where ((`t`.`majorID` = `m`.`majorID`) and (`m`.`instituteID` = `i`.`instituteID`));


create definer = root@localhost view view_institutechairman as
select `i`.`instituteID`   AS `学院编号`,
       `i`.`instituteName` AS `学院名称`,
       `t`.`teacherID`     AS `院长工号`,
       `t`.`teacherName`   AS `院长姓名`
from `php_liyang`.`teachers` `t`
         join `php_liyang`.`institutes` `i`
where (`i`.`instituteChargeID` = `t`.`teacherID`);


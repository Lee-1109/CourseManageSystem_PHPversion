create definer = root@localhost view view_grade as
select `c`.`courseID`     AS `courseID`,
       `c`.`courseName`   AS `courseName`,
       `s`.`studentID`    AS `studentID`,
       `s`.`studentName`  AS `studentName`,
       `c`.`credit`       AS `credit`,
       `c`.`coursePeriod` AS `coursePeriod`,
       `c`.`term`         AS `term`,
       `c`.`courseType`   AS `courseType`,
       `g`.`grade`        AS `grade`
from `php_liyang`.`grades` `g`
         join `php_liyang`.`courses` `c`
         join `php_liyang`.`students` `s`
where ((`g`.`courseID` = `c`.`courseID`) and (`g`.`studentID` = `s`.`studentID`));


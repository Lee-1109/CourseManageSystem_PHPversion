create definer = root@localhost view view_insmajorteacher as
select `i`.`instituteID`   AS `instituteID`,
       `i`.`instituteName` AS `instituteName`,
       `m`.`majorID`       AS `majorID`,
       `m`.`majorName`     AS `majorName`,
       `t`.`teacherID`     AS `teacherID`,
       `t`.`teacherName`   AS `teacherName`
from `php_liyang`.`institutes` `i`
         join `php_liyang`.`majors` `m`
         join `php_liyang`.`teachers` `t`
where ((`t`.`majorID` = `m`.`majorID`) and (`m`.`instituteID` = `i`.`instituteID`));

